import express from "express";
import {
  loginUser,
  protectedRoute,
  registerUser,
} from "../controllers/authControllers.ts";
import { authenticateToken } from "../middleware/authMiddleware.ts";

const router = express.Router();

//register
router.post("/register", registerUser);

//login
router.post("/login", loginUser);

//check for protected ROutes
router.get("/checkforprotectedroutes", authenticateToken, protectedRoute);

export default router;
