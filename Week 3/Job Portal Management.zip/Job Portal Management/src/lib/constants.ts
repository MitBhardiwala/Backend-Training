const API_MESSAGES = {
  USER: {
    ADD_SUCCESS: "User added successfully",
    ADD_ERROR: "Error in adding User",
    ALREADY_EXISTS: "User already exists, please logIn",
  },
  LOGIN: {
    SUCCESS: "Logged In successfully",
    ERROR: "Error in login",
  },
  DATA: {
    FETCH_SUCCESS: "Data fetched successfully",
    FETCH_ERROR: "Error in fetching data",
  },
  AUTH: {
    INVALID_TOKEN: "Invalid Token or Expired token",
    UNAUTHORIZED: "Unauthorized User",
  },
  VALIDATION: {
    ZOD_ERROR: "Zod validation error",
  },
};

export default API_MESSAGES;
